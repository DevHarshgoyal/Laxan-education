#!/usr/bin/env python3
"""
============================================================
  MySQL → DigitalOcean Full Table Replace Sync
  Truncates each target table and re-inserts all rows
  from local source in batches.
============================================================
"""

import mysql.connector
import logging
import sys
import time
import json
from datetime import datetime

# ── Logging setup ─────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("do_sync.log", encoding="utf-8"),
    ],
)
log = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════
#  CONFIGURATION  ← edit these values
# ══════════════════════════════════════════════════════════

LOCAL_DB = {
    "host":     "localhost",
    "port":     3306,
    "user":     "root",
    "password": "your_local_password",
    "database": "your_local_database",
}

DIGITAL_OCEAN_DB = {
    "host":            "your-cluster.db.ondigitalocean.com",
    "port":            25060,
    "user":            "doadmin",
    "password":        "your_do_password",
    "database":        "defaultdb",
    "ssl_ca":          "/path/to/ca-certificate.crt",   # downloaded from DO dashboard
    "ssl_verify_cert": True,
}

# List of exactly 20 tables to sync
TABLES_TO_SYNC = [
    "table1",  "table2",  "table3",  "table4",  "table5",
    "table6",  "table7",  "table8",  "table9",  "table10",
    "table11", "table12", "table13", "table14", "table15",
    "table16", "table17", "table18", "table19", "table20",
]

BATCH_SIZE = 1000   # rows inserted per batch (tune as needed)

# ══════════════════════════════════════════════════════════


def connect(cfg: dict, label: str):
    """Open a MySQL connection and return (conn, cursor)."""
    try:
        conn = mysql.connector.connect(**cfg)
        cur  = conn.cursor(dictionary=True)
        log.info(f"Connected to {label} ({cfg['host']}:{cfg['port']})")
        return conn, cur
    except mysql.connector.Error as e:
        log.error(f"Cannot connect to {label}: {e}")
        sys.exit(1)


def get_row_count(cur, table: str) -> int:
    cur.execute(f"SELECT COUNT(*) AS cnt FROM `{table}`")
    return cur.fetchone()["cnt"]


def ensure_table_exists(local_cur, do_cur, do_conn, table: str):
    """
    If the table doesn't exist on DO, create it using the local
    CREATE TABLE statement (structure copy).
    """
    do_cur.execute(
        "SELECT COUNT(*) AS cnt FROM information_schema.TABLES "
        "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
        (DIGITAL_OCEAN_DB["database"], table)
    )
    if do_cur.fetchone()["cnt"] == 0:
        log.info(f"  [{table}] Table not found on DO — creating …")
        local_cur.execute(f"SHOW CREATE TABLE `{table}`")
        row = local_cur.fetchone()
        create_sql = row["Create Table"]
        do_cur.execute(create_sql)
        do_conn.commit()
        log.info(f"  [{table}] Table created on DO ✓")


def sync_table(local_cur, do_cur, do_conn, table: str) -> dict:
    """
    Full replace for one table:
      1. Disable FK checks
      2. TRUNCATE target
      3. Fetch all rows from local in batches
      4. INSERT all rows into DO
      5. Re-enable FK checks
    Returns a result dict.
    """
    result = {"table": table, "status": "ok", "rows": 0, "elapsed": 0}
    t0 = time.time()

    try:
        # ── Safety: ensure table exists on DO ──────────────
        ensure_table_exists(local_cur, do_cur, do_conn, table)

        local_count = get_row_count(local_cur, table)
        log.info(f"  [{table}] Local rows: {local_count:,}")

        # ── Step 1: disable FK checks ──────────────────────
        do_cur.execute("SET FOREIGN_KEY_CHECKS = 0")

        # ── Step 2: truncate target table ─────────────────
        do_cur.execute(f"TRUNCATE TABLE `{table}`")
        do_conn.commit()
        log.info(f"  [{table}] Truncated ✓")

        # ── Step 3 & 4: fetch + insert in batches ─────────
        offset      = 0
        total_synced = 0

        while True:
            local_cur.execute(
                f"SELECT * FROM `{table}` LIMIT %s OFFSET %s",
                (BATCH_SIZE, offset)
            )
            rows = local_cur.fetchall()
            if not rows:
                break

            columns      = list(rows[0].keys())
            col_list     = ", ".join([f"`{c}`" for c in columns])
            placeholders = ", ".join(["%s"] * len(columns))
            insert_sql   = f"INSERT INTO `{table}` ({col_list}) VALUES ({placeholders})"

            batch_data = [tuple(r[c] for c in columns) for r in rows]
            do_cur.executemany(insert_sql, batch_data)
            do_conn.commit()

            total_synced += len(rows)
            offset       += BATCH_SIZE
            log.info(f"  [{table}] Inserted {total_synced:,}/{local_count:,} rows …")

        # ── Step 5: re-enable FK checks ───────────────────
        do_cur.execute("SET FOREIGN_KEY_CHECKS = 1")
        do_conn.commit()

        elapsed = round(time.time() - t0, 2)
        log.info(f"  [{table}] ✅ Done — {total_synced:,} rows in {elapsed}s")

        result["rows"]    = total_synced
        result["elapsed"] = elapsed

    except mysql.connector.Error as e:
        result["status"] = "error"
        result["error"]  = str(e)
        log.error(f"  [{table}] ❌ Error: {e}")
        # Re-enable FK checks even on failure
        try:
            do_cur.execute("SET FOREIGN_KEY_CHECKS = 1")
            do_conn.commit()
        except Exception:
            pass

    return result


def print_summary(results: list, total_elapsed: float):
    log.info("")
    log.info("=" * 60)
    log.info("  SYNC SUMMARY")
    log.info("=" * 60)
    ok     = [r for r in results if r["status"] == "ok"]
    errors = [r for r in results if r["status"] == "error"]

    for r in ok:
        log.info(f"  ✅  {r['table']:<20}  {r['rows']:>8,} rows   {r['elapsed']}s")
    for r in errors:
        log.error(f"  ❌  {r['table']:<20}  FAILED: {r.get('error','')}")

    log.info("-" * 60)
    log.info(f"  Tables OK   : {len(ok)}/{len(results)}")
    log.info(f"  Tables Failed: {len(errors)}/{len(results)}")
    log.info(f"  Total rows  : {sum(r['rows'] for r in ok):,}")
    log.info(f"  Total time  : {round(total_elapsed, 2)}s")
    log.info("=" * 60)

    # Save JSON report
    report = {
        "timestamp":    datetime.now().isoformat(),
        "total_elapsed": round(total_elapsed, 2),
        "results":       results,
    }
    with open("sync_report.json", "w") as f:
        json.dump(report, f, indent=2, default=str)
    log.info("  Report saved → sync_report.json")


def run():
    log.info("=" * 60)
    log.info("  MySQL → DigitalOcean Full Table Replace Sync")
    log.info(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log.info(f"  Tables : {len(TABLES_TO_SYNC)}")
    log.info("=" * 60)

    local_conn, local_cur = connect(LOCAL_DB,         "Local MySQL")
    do_conn,    do_cur    = connect(DIGITAL_OCEAN_DB, "DigitalOcean")

    results     = []
    global_start = time.time()

    for i, table in enumerate(TABLES_TO_SYNC, 1):
        log.info(f"\n[{i}/{len(TABLES_TO_SYNC)}] Syncing: {table}")
        result = sync_table(local_cur, do_cur, do_conn, table)
        results.append(result)

    total_elapsed = time.time() - global_start

    # Close connections
    local_cur.close()
    do_cur.close()
    local_conn.close()
    do_conn.close()

    print_summary(results, total_elapsed)


if __name__ == "__main__":
    run()
