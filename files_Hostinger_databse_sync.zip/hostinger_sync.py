#!/usr/bin/env python3
"""
============================================================
  MySQL → Hostinger Full Table Replace Sync
  Truncates each target table on Hostinger and re-inserts
  all rows from local source in batches.

  Hostinger specifics:
  - Standard port 3306 (no special port like DO's 25060)
  - SSL optional but recommended
  - Remote MySQL access must be enabled in hPanel
  - Connection via hostname like: srv1234.hstgr.io
============================================================
"""

import mysql.connector
import logging
import sys
import time
import json
from datetime import datetime

# ── Logging setup ─────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("hostinger_sync.log", encoding="utf-8"),
    ],
)
log = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════
#  CONFIGURATION  ← edit these values
# ══════════════════════════════════════════════════════════

LOCAL_DB = {
    "host":     "localhost",
    "port":     3306,
    "user":     "root",
    "password": "your_local_password",     # ← your local MySQL password
    "database": "your_local_database",    # ← your local DB name
}

HOSTINGER_DB = {
    # From hPanel → Databases → Remote MySQL
    # Hostname looks like: srv1234.hstgr.io  OR  your-domain.com
    "host":     "srv1234.hstgr.io",        # ← from hPanel → MySQL Databases → Host
    "port":     3306,                       # Hostinger uses standard 3306
    "user":     "u123456789_dbuser",        # ← from hPanel → MySQL Databases → Username
    "password": "your_hostinger_db_pass",  # ← the DB password you set
    "database": "u123456789_dbname",       # ← from hPanel → MySQL Databases → DB Name
    # SSL (optional but recommended for Hostinger shared/VPS)
    # "ssl_ca": "/path/to/hostinger-ca.crt",
    # "ssl_verify_cert": True,
}

# ── Your 20 tables to sync ────────────────────────────────
TABLES_TO_SYNC = [
    "table1",  "table2",  "table3",  "table4",  "table5",
    "table6",  "table7",  "table8",  "table9",  "table10",
    "table11", "table12", "table13", "table14", "table15",
    "table16", "table17", "table18", "table19", "table20",
]

BATCH_SIZE = 1000   # rows per batch — lower to 500 if you get timeouts

# ══════════════════════════════════════════════════════════


def connect(cfg: dict, label: str):
    """Open a MySQL connection, return (conn, cursor)."""
    try:
        conn = mysql.connector.connect(**cfg)
        cur  = conn.cursor(dictionary=True)
        log.info(f"✓ Connected to {label} ({cfg['host']}:{cfg['port']})")
        return conn, cur
    except mysql.connector.Error as e:
        log.error(f"✗ Cannot connect to {label}: {e}")
        log.error("  → Check host, user, password, and Remote MySQL whitelist in hPanel")
        sys.exit(1)


def get_row_count(cur, table: str) -> int:
    cur.execute(f"SELECT COUNT(*) AS cnt FROM `{table}`")
    return cur.fetchone()["cnt"]


def ensure_table_exists(local_cur, h_cur, h_conn, table: str):
    """
    If table doesn't exist on Hostinger, auto-create it
    by copying the CREATE TABLE structure from local.
    """
    h_cur.execute(
        "SELECT COUNT(*) AS cnt FROM information_schema.TABLES "
        "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
        (HOSTINGER_DB["database"], table)
    )
    if h_cur.fetchone()["cnt"] == 0:
        log.info(f"  [{table}] Not found on Hostinger — auto-creating …")
        local_cur.execute(f"SHOW CREATE TABLE `{table}`")
        row = local_cur.fetchone()
        create_sql = row["Create Table"]
        # Strip AUTO_INCREMENT value so it starts fresh
        import re
        create_sql = re.sub(r"AUTO_INCREMENT=\d+\s*", "", create_sql)
        h_cur.execute(create_sql)
        h_conn.commit()
        log.info(f"  [{table}] Table created on Hostinger ✓")


def sync_table(local_cur, h_cur, h_conn, table: str) -> dict:
    """
    Full replace for one table:
      1. Ensure table exists on Hostinger
      2. Disable FK checks
      3. TRUNCATE
      4. Batch INSERT all rows from local
      5. Re-enable FK checks
    """
    result = {"table": table, "status": "ok", "rows": 0, "elapsed": 0}
    t0 = time.time()

    try:
        ensure_table_exists(local_cur, h_cur, h_conn, table)

        local_count = get_row_count(local_cur, table)
        log.info(f"  [{table}] Source rows: {local_count:,}")

        # Step 1: disable FK constraints
        h_cur.execute("SET FOREIGN_KEY_CHECKS = 0")

        # Step 2: wipe existing data on Hostinger
        h_cur.execute(f"TRUNCATE TABLE `{table}`")
        h_conn.commit()
        log.info(f"  [{table}] Truncated on Hostinger ✓")

        # Step 3: fetch + insert in batches
        offset       = 0
        total_synced = 0

        while True:
            local_cur.execute(
                f"SELECT * FROM `{table}` LIMIT %s OFFSET %s",
                (BATCH_SIZE, offset)
            )
            rows = local_cur.fetchall()
            if not rows:
                break

            columns      = list(rows[0].keys())
            col_list     = ", ".join([f"`{c}`" for c in columns])
            placeholders = ", ".join(["%s"] * len(columns))
            insert_sql   = f"INSERT INTO `{table}` ({col_list}) VALUES ({placeholders})"

            batch_data = [tuple(r[c] for c in columns) for r in rows]
            h_cur.executemany(insert_sql, batch_data)
            h_conn.commit()

            total_synced += len(rows)
            offset       += BATCH_SIZE
            pct = int((total_synced / local_count) * 100) if local_count else 100
            log.info(f"  [{table}] Progress: {total_synced:,}/{local_count:,} rows ({pct}%) …")

        # Step 4: re-enable FK constraints
        h_cur.execute("SET FOREIGN_KEY_CHECKS = 1")
        h_conn.commit()

        elapsed = round(time.time() - t0, 2)
        log.info(f"  [{table}] ✅ Complete — {total_synced:,} rows in {elapsed}s")

        result["rows"]    = total_synced
        result["elapsed"] = elapsed

    except mysql.connector.Error as e:
        result["status"] = "error"
        result["error"]  = str(e)
        log.error(f"  [{table}] ❌ Failed: {e}")
        try:
            h_cur.execute("SET FOREIGN_KEY_CHECKS = 1")
            h_conn.commit()
        except Exception:
            pass

    return result


def print_summary(results: list, total_elapsed: float):
    log.info("")
    log.info("=" * 62)
    log.info("  SYNC SUMMARY — MySQL → Hostinger")
    log.info("=" * 62)

    ok     = [r for r in results if r["status"] == "ok"]
    errors = [r for r in results if r["status"] == "error"]

    for r in ok:
        log.info(f"  ✅  {r['table']:<22}  {r['rows']:>8,} rows   {r['elapsed']}s")
    for r in errors:
        log.error(f"  ❌  {r['table']:<22}  FAILED → {r.get('error', '')}")

    log.info("-" * 62)
    log.info(f"  Tables synced : {len(ok)}/{len(results)}")
    log.info(f"  Tables failed : {len(errors)}/{len(results)}")
    log.info(f"  Total rows    : {sum(r['rows'] for r in ok):,}")
    log.info(f"  Total time    : {round(total_elapsed, 2)}s")
    log.info("=" * 62)

    report = {
        "timestamp":     datetime.now().isoformat(),
        "target":        "Hostinger",
        "total_elapsed": round(total_elapsed, 2),
        "tables_ok":     len(ok),
        "tables_failed": len(errors),
        "results":       results,
    }
    with open("hostinger_sync_report.json", "w") as f:
        json.dump(report, f, indent=2, default=str)
    log.info("  Report saved → hostinger_sync_report.json")


def run():
    log.info("=" * 62)
    log.info("  MySQL → Hostinger Full Table Replace Sync")
    log.info(f"  Started : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log.info(f"  Tables  : {len(TABLES_TO_SYNC)}")
    log.info(f"  Batch   : {BATCH_SIZE} rows/batch")
    log.info("=" * 62)

    local_conn, local_cur = connect(LOCAL_DB,      "Local MySQL")
    h_conn,     h_cur     = connect(HOSTINGER_DB,  "Hostinger MySQL")

    results      = []
    global_start = time.time()

    for i, table in enumerate(TABLES_TO_SYNC, 1):
        log.info(f"\n── [{i}/{len(TABLES_TO_SYNC)}] {table} ──")
        result = sync_table(local_cur, h_cur, h_conn, table)
        results.append(result)

    total_elapsed = time.time() - global_start

    local_cur.close()
    h_cur.close()
    local_conn.close()
    h_conn.close()

    print_summary(results, total_elapsed)


if __name__ == "__main__":
    run()
